#include <rclcpp/rclcpp.hpp>
#include <std_msgs/msg/string.hpp>
#include <std_msgs/msg/byte.hpp>
#include <geometry_msgs/msg/point.hpp>
#include <sensor_msgs/msg/joy.hpp> 
#include <nav_msgs/msg/odometry.hpp>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <cstring>
#include <mutex>
#include <thread>
#include <chrono>
#include <vector>
#include <sstream>
#include <iomanip>
#include <algorithm>
#include <fstream>
#include <string>
#include <std_srvs/srv/trigger.hpp>
#include <std_msgs/msg/float32_multi_array.hpp>
#include <nav_msgs/msg/path.hpp> 
#include <sensor_msgs/msg/point_cloud2.hpp>
#include <sensor_msgs/point_cloud2_iterator.hpp>

// 配置常量
const std::string REMOTE_SERVER_IP = "39.103.70.59";
const int REMOTE_SERVER_PORT = 9001;
const int RECONNECT_INTERVAL_SEC = 5; // 重连间隔秒数

struct Point {
    std::string id;
    double x, y, z;
    Point(const std::string& i, double x_val, double y_val, double z_val)
        : id(i), x(x_val), y(y_val), z(z_val) {}
};

class RemoteControlNode : public rclcpp::Node
{
public:
    RemoteControlNode()
    : Node("remote_control_node") {
        // 读取 waypoints 文件
        std::string home = std::getenv("HOME");
        if (!home.empty()) {
            std::string file_path = home + "/gnss_waypoints.txt";
            all_points_ = parsePoints(file_path);
            if (all_points_.empty()) {
                RCLCPP_WARN(this->get_logger(), "未能读取到任何有效点位 (文件可能不存在或为空)，将继续运行但无法发送全量点。");
            }
        } else {
            RCLCPP_WARN(this->get_logger(), "HOME 环境变量未设置，无法读取 waypoints 文件。");
        }

        // 初始化发布者
        command_pub_ = this->create_publisher<std_msgs::msg::String>("remote_command", 10);
        joy_pub_ = this->create_publisher<sensor_msgs::msg::Joy>("/joy", 10);

        // 初始化订阅者
        progress_sub_ = this->create_subscription<std_msgs::msg::Byte>("/progress", 10,
            [this](const std_msgs::msg::Byte::SharedPtr msg) {
                sendProgress(msg->data);
            });
        position_sub_ = this->create_subscription<nav_msgs::msg::Odometry>("/b2w_odom", 10,
            [this](const nav_msgs::msg::Odometry::SharedPtr msg) {
                sendPosition(msg->pose.pose.position.x, msg->pose.pose.position.y, msg->pose.pose.position.z);
            });
        motors_temp_sub_ = this->create_subscription<std_msgs::msg::Float32MultiArray>("/motors_temperatures", 10,
            [this](const std_msgs::msg::Float32MultiArray::SharedPtr msg) {
                sendMaxTemperature(msg->data);
            });
        path_sub_ = this->create_subscription<nav_msgs::msg::Path>("/b2w_path", 10,
            [this](const nav_msgs::msg::Path::SharedPtr msg) {
                sendPath(msg);
            });
        acquired_points_sub_ = this->create_subscription<sensor_msgs::msg::PointCloud2>(
            "/acquired_points", 10, [this](const sensor_msgs::msg::PointCloud2::SharedPtr msg) {
                sendPointCloud(msg, 0x02);
            });
        unacquired_points_sub_ = this->create_subscription<sensor_msgs::msg::PointCloud2>(
            "/unacquired_points", 10, [this](const sensor_msgs::msg::PointCloud2::SharedPtr msg) {
                sendPointCloud(msg, 0x03);
            });

        // 初始化服务客户端
        emergency_stop_client_ = this->create_client<std_srvs::srv::Trigger>("/emergency_stop");
        erase_emergency_stop_client_ = this->create_client<std_srvs::srv::Trigger>("/erase_emergency_stop");

        // 启动 TCP 客户端线程
        tcp_thread_ = std::thread(&RemoteControlNode::runTcpClient, this);
        
        RCLCPP_INFO(this->get_logger(), "Node initialized. Attempting to connect to %s:%d", REMOTE_SERVER_IP.c_str(), REMOTE_SERVER_PORT);
    }

    ~RemoteControlNode() {
        running_ = false;
        {
            std::lock_guard<std::mutex> lock(client_mutex_);
            if (client_sock_ >= 0) {
                close(client_sock_);
                client_sock_ = -1;
            }
        }
        if (tcp_thread_.joinable()) {
            tcp_thread_.join();
        }
    }

private:
    void runTcpClient()
    {
        struct sockaddr_in serv_addr;
        
        while (rclcpp::ok() && running_) {
            int sock = -1;
            if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
                RCLCPP_ERROR(this->get_logger(), "Socket creation failed");
                std::this_thread::sleep_for(std::chrono::seconds(RECONNECT_INTERVAL_SEC));
                continue;
            }

            serv_addr.sin_family = AF_INET;
            serv_addr.sin_port = htons(REMOTE_SERVER_PORT);

            // 转换 IP 地址
            if (inet_pton(AF_INET, REMOTE_SERVER_IP.c_str(), &serv_addr.sin_addr) <= 0) {
                RCLCPP_ERROR(this->get_logger(), "Invalid address/ Address not supported: %s", REMOTE_SERVER_IP.c_str());
                close(sock);
                std::this_thread::sleep_for(std::chrono::seconds(RECONNECT_INTERVAL_SEC));
                continue;
            }

            RCLCPP_INFO(this->get_logger(), "Connecting to %s:%d ...", REMOTE_SERVER_IP.c_str(), REMOTE_SERVER_PORT);
            
            // 尝试连接 (这里可以设置为非阻塞，但为了简单先使用阻塞 + 超时逻辑需自行实现，此处简化为直接连接)
            // 注意：默认 connect 是阻塞的，可能会卡住较久。生产环境建议设置 SO_SNDTIMEO/SO_RCVTIMEO 或使用非阻塞 socket。
            if (connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) {
                RCLCPP_WARN(this->get_logger(), "Connection failed. Retrying in %d seconds...", RECONNECT_INTERVAL_SEC);
                close(sock);
                std::this_thread::sleep_for(std::chrono::seconds(RECONNECT_INTERVAL_SEC));
                continue;
            }

            RCLCPP_INFO(this->get_logger(), "Connected to server successfully!");

            // 更新全局 socket 句柄
            {
                std::lock_guard<std::mutex> lock(client_mutex_);
                if (client_sock_ >= 0) close(client_sock_); // 关闭旧连接
                client_sock_ = sock;
            }

            // 连接成功后，立即发送全量点位 (0x01)
            sendAllPoints();

            // 处理接收数据
            handleClient(sock);

            // 如果 handleClient 返回，说明连接断开
            RCLCPP_WARN(this->get_logger(), "Connection lost. Reconnecting...");
            {
                std::lock_guard<std::mutex> lock(client_mutex_);
                if (client_sock_ == sock) {
                    client_sock_ = -1;
                }
            }
            close(sock);
            
            // 重连前等待
            std::this_thread::sleep_for(std::chrono::seconds(RECONNECT_INTERVAL_SEC));
        }
    }

    void handleClient(int sock)
    {
        std::vector<uint8_t> buffer(4096); // 增大缓冲区以应对可能的数据包堆积
        while (rclcpp::ok() && running_) {
            ssize_t bytes = recv(sock, buffer.data(), buffer.size(), 0);
            if (bytes <= 0) {
                if (bytes == 0) {
                    RCLCPP_INFO(this->get_logger(), "Server closed connection.");
                } else {
                    RCLCPP_ERROR(this->get_logger(), "Recv error: %s", strerror(errno));
                }
                break; // 退出循环，触发重连
            }

            size_t index = 0;
            while (index + 7 <= static_cast<size_t>(bytes)) {
                if (buffer[index] != 0xF5) {
                    index++;
                    continue;
                }
                
                // 防止越界读取长度
                if (index + 3 >= static_cast<size_t>(bytes)) break;

                uint8_t func_code = buffer[index + 1];
                uint16_t data_len = buffer[index + 2] | (static_cast<uint16_t>(buffer[index + 3]) << 8);
                
                // 协议总长度：Header(1) + Func(1) + Len(2) + Data(data_len) + CRC(2) + Tail(1)
                size_t total_len = 1 + 1 + 2 + data_len + 2 + 1; 
                
                if (index + total_len > static_cast<size_t>(bytes)) {
                    break; // 包不完整，等待更多数据
                }

                if (buffer[index + total_len - 1] != 0x5F) {
                    RCLCPP_WARN(this->get_logger(), "Invalid tail byte, skipping frame.");
                    index++;
                    continue;
                }

                // --- 解析指令 ---
                // 假设数据段第一个字节是指令类型 (根据原代码逻辑 func_code==0x08 时)
                if (func_code == 0x08) {
                    if (data_len >= 1) {
                        uint8_t instruction_type = buffer[index + 4]; // Header(1)+Func(1)+Len(2) -> Data start at +4
                        processInstruction(instruction_type);
                    }
                } else {
                    RCLCPP_WARN_ONCE(this->get_logger(), "Received unsupported function code: 0x%02X", func_code);
                }

                index += total_len;
            }
        }
    }

    void processInstruction(uint8_t instruction_type) {
        std::string cmd_str;
        if (instruction_type >= 0x01 && instruction_type <= 0x03) {
            switch (instruction_type) {
                case 0x01: 
                    cmd_str = "start"; 
                    RCLCPP_INFO(this->get_logger(), "Executing START command");
                    system("setsid /home/test/start_all.sh &");
                    break;
                case 0x02: 
                    cmd_str = "pause"; 
                    RCLCPP_INFO(this->get_logger(), "Executing PAUSE command (Emergency Stop)");
                    triggerService(emergency_stop_client_, "Emergency Stop");
                    break;
                case 0x03: 
                    cmd_str = "stop";  
                    RCLCPP_INFO(this->get_logger(), "Executing STOP command");
                    system("pkill -f start_all.sh");
                    break;
                default: break;
            }
            auto msg = std_msgs::msg::String();
            msg.data = cmd_str;
            command_pub_->publish(msg);
        } 
        else if (instruction_type >= 0x04 && instruction_type <= 0x09) {
            auto joy_msg = std::make_shared<sensor_msgs::msg::Joy>();
            joy_msg->axes.resize(3, 0.0); // [lateral, forward, yaw]
            joy_msg->buttons.clear();
            const float speed = 0.5f;
            switch (instruction_type) {
                case 0x04: joy_msg->axes[1] =  speed; break; // 前进
                case 0x05: joy_msg->axes[1] = -speed; break; // 后退
                case 0x06: joy_msg->axes[0] =  speed; break; // 左移
                case 0x07: joy_msg->axes[0] = -speed; break; // 右移
                case 0x08: joy_msg->axes[2] = -speed; break; // 左转
                case 0x09: joy_msg->axes[2] =  speed; break; // 右转
                default: break;
            }
            joy_pub_->publish(*joy_msg);
            RCLCPP_DEBUG(this->get_logger(), "Published Joy for instruction 0x%02X", instruction_type);
        } 
        else if (instruction_type == 0x10) {
            RCLCPP_INFO(this->get_logger(), "Executing ERASE EMERGENCY STOP command");
            triggerService(erase_emergency_stop_client_, "Erase Emergency Stop");
        } 
        else {
            RCLCPP_WARN(this->get_logger(), "Unknown instruction type: 0x%02X", instruction_type);
        }
    }

    void triggerService(rclcpp::Client<std_srvs::srv::Trigger>::SharedPtr client, const std::string& name) {
        if (!client->wait_for_service(std::chrono::seconds(2))) {
            RCLCPP_WARN(this->get_logger(), "%s service is not available.", name.c_str());
            return;
        }
        auto request = std::make_shared<std_srvs::srv::Trigger::Request>();
        auto future = client->async_send_request(request);
        // 注意：在回调线程中 spin_until_future_complete 可能会导致死锁或阻塞，
        // 在单线程 executor 或特定上下文中需谨慎。这里为了保持原逻辑暂时保留，
        // 但在实际高实时性场景中建议使用异步回调处理 future。
        if (rclcpp::spin_until_future_complete(this->get_node_base_interface(), future, std::chrono::seconds(5)) == rclcpp::FutureReturnCode::SUCCESS) {
            auto response = future.get();
            if (response->success) {
                RCLCPP_INFO(this->get_logger(), "%s triggered successfully.", name.c_str());
            } else {
                RCLCPP_WARN(this->get_logger(), "Failed to trigger %s: %s", name.c_str(), response->message.c_str());
            }
        } else {
            RCLCPP_WARN(this->get_logger(), "Service call to %s timed out.", name.c_str());
        }
    }

    // --- 发送函数组 (保持逻辑不变，增加连接检查) ---

    void sendPointCloud(const sensor_msgs::msg::PointCloud2::SharedPtr cloud, uint8_t func_code)
    {
        std::lock_guard<std::mutex> lock(client_mutex_);
        if (client_sock_ < 0) return;

        size_t num_points = cloud->width * cloud->height;
        if (num_points == 0) return;
        
        try {
            sensor_msgs::PointCloud2ConstIterator<double> iter_x(*cloud, "x");
            sensor_msgs::PointCloud2ConstIterator<double> iter_y(*cloud, "y");
            sensor_msgs::PointCloud2ConstIterator<double> iter_z(*cloud, "z");
            
            size_t data_len = num_points * 24; 
            size_t packet_len = 1 + 1 + 2 + data_len + 2 + 1;
            std::vector<uint8_t> packet(packet_len);
            size_t idx = 0;

            packet[idx++] = 0xF5;
            packet[idx++] = func_code;
            packet[idx++] = num_points & 0xFF;
            packet[idx++] = (num_points >> 8) & 0xFF;

            for (size_t i = 0; i < num_points; ++i, ++iter_x, ++iter_y, ++iter_z) {
                double x = *iter_x;
                double y = *iter_y;
                double z = *iter_z;
                std::memcpy(&packet[idx], &x, sizeof(double)); idx += sizeof(double);
                std::memcpy(&packet[idx], &y, sizeof(double)); idx += sizeof(double);
                std::memcpy(&packet[idx], &z, sizeof(double)); idx += sizeof(double);
            }
            packet[idx++] = 0;   
            packet[idx++] = 0;   
            packet[idx++] = 0x5F; 
            
            send(client_sock_, packet.data(), packet.size(), 0);
        } catch (const std::exception& e) {
            RCLCPP_ERROR(this->get_logger(), "Failed to send PointCloud: %s", e.what());
        }
    }

    void sendAllPoints()
    {
        std::lock_guard<std::mutex> lock(client_mutex_);
        if (client_sock_ < 0) return;
        if (all_points_.empty()) return;

        size_t num_points = all_points_.size();
        size_t data_len = num_points * 24; 
        size_t packet_len = 1 + 1 + 2 + data_len + 2 + 1;

        std::vector<uint8_t> packet(packet_len);
        size_t idx = 0;
        packet[idx++] = 0xF5;      
        packet[idx++] = 0x01;      
        packet[idx++] = num_points & 0xFF;         
        packet[idx++] = (num_points >> 8) & 0xFF;

        for (const auto& p : all_points_) {
            std::memcpy(&packet[idx], &p.x, sizeof(double)); idx += sizeof(double);
            std::memcpy(&packet[idx], &p.y, sizeof(double)); idx += sizeof(double);
            std::memcpy(&packet[idx], &p.z, sizeof(double)); idx += sizeof(double);
        }
        packet[idx++] = 0x00; 
        packet[idx++] = 0x00; 
        packet[idx++] = 0x5F; 
        
        send(client_sock_, packet.data(), packet.size(), 0);
        RCLCPP_INFO(this->get_logger(), "Sent ALL points (%zu points) to server.", num_points);
    }

    void sendProgress(uint8_t progress)
    {
        std::lock_guard<std::mutex> lock(client_mutex_);
        if (client_sock_ < 0) return;
        uint8_t packet[] = { 0xF5, 0x06, progress, 0x00, 0x00, 0x5F };
        send(client_sock_, packet, sizeof(packet), 0);
    }

    void sendPosition(double x, double y, double z) {
        std::lock_guard<std::mutex> lock(client_mutex_);
        if (client_sock_ < 0) return;
        
        uint8_t packet[1 + 1 + 3*8 + 2 + 1]; 
        size_t idx = 0;
        packet[idx++] = 0xF5;               
        packet[idx++] = 0x07;               

        std::memcpy(&packet[idx], &x, sizeof(double)); idx += sizeof(double);
        std::memcpy(&packet[idx], &y, sizeof(double)); idx += sizeof(double);
        std::memcpy(&packet[idx], &z, sizeof(double)); idx += sizeof(double);

        packet[idx++] = 0x00;               
        packet[idx++] = 0x00;               
        packet[idx++] = 0x5F;               

        send(client_sock_, packet, sizeof(packet), 0);
    }

    void sendMaxTemperature(const std::vector<float>& temps)
    {
        if (temps.empty()) return;
        float max_temp_f = *std::max_element(temps.begin(), temps.end());
        uint8_t temp_byte = static_cast<uint8_t>(std::min(std::max(max_temp_f, 0.0f), 255.0f));

        std::lock_guard<std::mutex> lock(client_mutex_);
        if (client_sock_ < 0) return;

        uint8_t packet[6] = { 0xF5, 0x05, temp_byte, 0x00, 0x00, 0x5F };
        send(client_sock_, packet, sizeof(packet), 0);
    }

    void sendPath(const nav_msgs::msg::Path::SharedPtr path_msg)
    {
        std::lock_guard<std::mutex> lock(client_mutex_);
        if (client_sock_ < 0 || path_msg->poses.empty()) return;

        uint8_t N = static_cast<uint8_t>(path_msg->poses.size());
        if (path_msg->poses.size() > 255) {
             N = 255;
        }
        
        size_t points_data_len = N * 24; 
        size_t packet_len = 1 + 1 + 1 + points_data_len + 2 + 1; 
        
        std::vector<uint8_t> packet(packet_len, 0);
        size_t idx = 0;
        packet[idx++] = 0xF5; 
        packet[idx++] = 0x04; 
        packet[idx++] = N;    

        for (int i = 0; i < N; ++i) {
            const auto &pose_stamped = path_msg->poses[i];
            double x = pose_stamped.pose.position.x;
            double y = pose_stamped.pose.position.y;
            double z = pose_stamped.pose.position.z;
            
            std::memcpy(&packet[idx], &x, sizeof(double)); idx += sizeof(double);
            std::memcpy(&packet[idx], &y, sizeof(double)); idx += sizeof(double);
            std::memcpy(&packet[idx], &z, sizeof(double)); idx += sizeof(double);
        }

        packet[idx++] = 0x00; 
        packet[idx++] = 0x00; 
        packet[idx++] = 0x5F; 

        send(client_sock_, packet.data(), packet.size(), 0);
    }

    std::vector<Point> parsePoints(const std::string& filename) {
        std::vector<Point> points;
        std::ifstream file(filename);
        if (!file.is_open()) {
            return points;
        }

        std::string line; 
        while (std::getline(file, line)) {
            if (line.empty() || line[0] == '#') continue;
            std::stringstream ss(line);
            std::string id, x_str, y_str, z_str;
            if (std::getline(ss, id, ',') &&
                std::getline(ss, x_str, ',') &&
                std::getline(ss, y_str, ',') &&
                std::getline(ss, z_str, ',')) {
                try {
                    points.emplace_back(id, std::stod(x_str), std::stod(y_str), std::stod(z_str));
                } catch (...) {
                    continue;
                }
            }
        }
        return points;
    }

    // 成员变量
    rclcpp::Publisher<std_msgs::msg::String>::SharedPtr command_pub_;
    rclcpp::Publisher<sensor_msgs::msg::Joy>::SharedPtr joy_pub_;
    rclcpp::Subscription<std_msgs::msg::Byte>::SharedPtr progress_sub_;
    rclcpp::Subscription<nav_msgs::msg::Odometry>::SharedPtr position_sub_;
    rclcpp::Subscription<std_msgs::msg::Float32MultiArray>::SharedPtr motors_temp_sub_;
    rclcpp::Subscription<nav_msgs::msg::Path>::SharedPtr path_sub_;
    rclcpp::Subscription<sensor_msgs::msg::PointCloud2>::SharedPtr acquired_points_sub_;
    rclcpp::Subscription<sensor_msgs::msg::PointCloud2>::SharedPtr unacquired_points_sub_;
    rclcpp::Client<std_srvs::srv::Trigger>::SharedPtr emergency_stop_client_;
    rclcpp::Client<std_srvs::srv::Trigger>::SharedPtr erase_emergency_stop_client_;

    std::vector<Point> all_points_;
    
    std::thread tcp_thread_;
    int client_sock_ = -1;          
    std::mutex client_mutex_;       
    std::atomic<bool> running_{true}; // 控制线程退出的标志
};

int main(int argc, char * argv[])
{
    rclcpp::init(argc, argv);
    auto node = std::make_shared<RemoteControlNode>();
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}